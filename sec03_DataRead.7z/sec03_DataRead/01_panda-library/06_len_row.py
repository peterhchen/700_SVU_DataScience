
import pandas as pd

df = pd.read_csv ('PastHires.csv')
print ('df.shape:', df.shape)   # (13, 7)
print ('len(df):', len(df))     # 13