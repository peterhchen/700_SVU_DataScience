import pandas as pd

df = pd.read_csv ('PastHires.csv')
print ('df.shape:', df.shape)   # df.shape: (13, 7)
print ('df.size:', df.size)     # df.size: 91
