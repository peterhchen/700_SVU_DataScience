import pandas as pd

df = pd.read_csv ('PastHires.csv')
print ('df.shape:', df.shape)
