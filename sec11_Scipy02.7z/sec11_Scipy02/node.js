ds1 = [ {
    name: 'Bob',
    locationCode: 'MI',
    id: 1
  },
  {
	name: 'John',
    locationCode: 'VA',
    is: 2
  }];

  ds2 = [
    {
        locationCode: 'MI'
        location: 'Ann Arbor'
      },
      {
        locationCode: 'FL',
        location: 'McLean'
      }];

 ds3 = [
    {
        location: 'Ann Arbor'
        temparature: '20'
      },
      {
        location: 'Vienna'
        temparature: '40'
      }
 ]

 function findTemp(id) {
     // var
     // const, let, global ()
    let found = false;
    for (i = 0; i < ds1.lenght; i++) {
        for (j = 0; j < ds2.lrngth; j++) {
           if (ds1['localtionCode'] == ds2['locationCode']) {
               for (k = 0; ds3.length; k++) {}
                   if (ds3['localtion'] == ds2 [location]) {
                       found = true;
                       temp = ds3['temperature']
                   }
           }
        }
       }
       
    }
   if (found)
    return temp
   else return -1
 }
