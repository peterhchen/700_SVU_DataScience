# https://realpython.com/introduction-to-python-generators/#example-1-reading-large-files

def infinite_sequence():
    num = 0
    while True:
        yield num
        num += 1

for i in infinite_sequence():
    print(i, end=" ")

gen = infinite_sequence()
next(gen)
#0
next(gen)
#1
next(gen)
#2
next(gen)
#3