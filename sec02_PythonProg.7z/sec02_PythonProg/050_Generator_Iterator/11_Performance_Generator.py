# https://www.youtube.com/watch?v=bD05uGo_sVI
# 
import memory_profiler as mem_profile
import random
import time

names = ['John', 'Corey', 'Adam', 'Steve', 'Rick', 'Thomas']
majors = ['Math', 'Engineering', 'CompSci', 'Arts', 'Business']

def people_list (num_people):
    result = []
    for i in range(num_people):
        person = { 
            'id': i,
            'name': random.choice(names),
            'major': random.choice(majors)
        }
        result.append(person)
    return result

def people_generator (num_people):
    for i in xrange(num_people):
        person = { 
            'id': i,
            'name': random.choice(names),
            'major': random.choice(majors)
        }
        yield person

print ('Iterator => Memory (before): {}MB'.format(mem_profile.memory_usage()))
t1 = time.process_time()
print('people_list () with traditional return: ')
print('1. Memory grow with passing data.')
print('2: Execution speed becomes very slow when passing data size is very big.')
print('people_list(1000000):')
people_list(1000000)
t2 =  time.process_time()
print('t2 - t1:', t2 - t1)
print ('Iterator => Memory (after): {}MB'.format(mem_profile.memory_usage()))
# Iterator => Memory (before): [40.7734375]MB
# people_list(1000000):
# t2 - t1: 1.453125
# Iterator => Memory (after): [41.25]MB

print()
print('people_generator () with yeild instead of return: ')
print('1. Memory consumption is very small.')
print('2. Execution speed is very fast.')
print ('Memory (before): {}MB'.format(mem_profile.memory_usage()))
t1 =  time.process_time()
print('Generator => people_generator(1000000):')
print(people_generator(1000000))
t2 =  time.process_time()
print('t2 - t1:', t2 - t1)
print ('Generator =>Memory (after): {}MB'.format(mem_profile.memory_usage()))
# Memory (before): [41.25]MB
# Generator => people_generator(1000000):
# <generator object people_generator at 0x0000018F035AD648>
# t2 - t1: 0.0
# Generator =>Memory (after): [41.25]MB