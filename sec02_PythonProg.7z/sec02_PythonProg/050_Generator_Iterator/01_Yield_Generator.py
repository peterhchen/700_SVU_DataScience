# https://www.youtube.com/watch?v=mziIj4M_uwk
# Generator will give you the iterator
# When you have millions of record, these records will ruin your memory.
# This is why the yield and generator comes in. 
# Instead of store in a list and then return,
# you want to return one value at a time.


def topten ():
    yield 1 # return one value at a time.
    yield 2
    yield 3
    yield 4
    yield 5

values = topten()

print('1 => values.__next__():', values.__next__())
print('2 => values.__next__():', values.__next__())
print('3 => values.__next__():', values.__next__())

print('Rest of them by iteration loop:')
for i in values:
    print('i:', i)