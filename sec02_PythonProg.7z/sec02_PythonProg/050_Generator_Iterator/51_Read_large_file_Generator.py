# https://realpython.com/introduction-to-python-generators/#example-1-reading-large-files

# When reading a big file, we have the following Memory errors:
 
# Traceback (most recent call last):
#   File "ex1_naive.py", line 22, in <module>
#     main()
#   File "ex1_naive.py", line 13, in main
#     csv_gen = csv_reader("file.txt")
#   File "ex1_naive.py", line 6, in csv_reader
#     result = file.read().split("\n")
# MemoryError
def csv_reader(file_name):
    file = open(file_name)
    result = file.read().split("\n")
    return result

#We have memory error in reading the big file.
csv_gen = csv_reader("some_csv.txt")
row_count = 0

for row in csv_gen:
    row_count += 1
print(f"Row count is {row_count}")

# Open a file and iterate through it and yield a row.
def csv_reader_yield(file_name):
    for row in open(file_name, "r"):
        yield row
csv_gen = csv_reader_yield("some_csv.txt")
csv_gen = (row for row in open(file_name))

