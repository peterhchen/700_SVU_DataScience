# https://www.youtube.com/watch?v=mziIj4M_uwk
# Generator will give you the iterator

def topten ():
    n = 1
    while n <= 10:
        sq = n * n
        yield sq
        n += 1

values = topten()

print('1 => values.__next__():', values.__next__())
print('2 => values.__next__():', values.__next__())
print('3 => values.__next__():', values.__next__())

print('Rest of them by iterator loop:')
for i in values:
    print('i:', i)