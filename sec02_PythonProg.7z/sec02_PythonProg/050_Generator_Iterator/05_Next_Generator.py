# https://www.youtube.com/watch?v=bD05uGo_sVI
# This is the Iterator Example.

# This is the Iterator example. 
# We store the result in the list which consume the memory.
def square_numbers (nums):
    for i in nums:
        yield(i * i)
    

my_nums = square_numbers ([1, 2, 3, 4, 5])
# my_num = [x * x for x in [1, 2, 3, 4, 5]]

#print('my_nums:', my_nums)
# We no longer getting this => my_nums: [1, 4, 9, 16, 25]
# Instead: We got the generator output:
# my_nums: <generator object square_numbers at 0x000001EC770938C8>
# Generator do not hold the entire result in the memory.
# It give you one result at a time.
# It wait us for print more in the memory.

print('1 => next(my_nums):', next(my_nums))
print('2 => next(my_nums):', next(my_nums))

print('by iteration style:')
for num in my_nums:
    print('num:', num)