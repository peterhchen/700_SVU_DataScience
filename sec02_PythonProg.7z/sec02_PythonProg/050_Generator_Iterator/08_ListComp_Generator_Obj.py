# https://www.youtube.com/watch?v=bD05uGo_sVI
# This is the Iterator Example.

# This is the Iterator example. 
# We store the result in the list which consume the memory.
def square_numbers (nums):
    for i in nums:
        yield(i * i)
    

# my_nums = square_numbers ([1, 2, 3, 4, 5])
# my_nums = [x * x for x in [1, 2, 3, 4, 5]]

# Use generator, we use () instead of []
my_nums = (x * x for x in [1, 2, 3, 4, 5])

print('my_nums:', my_nums)
# my_nums: <generator object <genexpr> at 0x00000236E53C3F48>
# we only can see the object

#print('by iteration style:')
#for num in my_nums:
#    print('num:', num)