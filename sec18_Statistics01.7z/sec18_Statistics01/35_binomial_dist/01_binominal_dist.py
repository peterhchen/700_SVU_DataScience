from scipy.stats import binom
import seaborn as sb
import matplotlib.pyplot as plt

# binomial: P (x) = C(n, x) * p^x * q ^ (n-x) 
# = {n!/[(n-x)! * x!]} * p^ x * q ^ (n - x)
# rvs: Random Variable Sample
# size: shape of random variables
# n, p: shape parameter
binom.rvs(size=10,n=20,p=0.8)

data_binom = binom.rvs(n=20,p=0.8,loc=0,size=1000)
ax = sb.distplot(data_binom,
                  kde=True,
                  color='blue',
                  hist_kws={"linewidth": 25,'alpha':1})
ax.set(xlabel='Binomial', ylabel='Frequency')
plt.show()