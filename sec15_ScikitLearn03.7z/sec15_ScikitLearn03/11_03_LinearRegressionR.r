# Create data frame for wieght and size
mouse.data <- data.frame(
weight=c(0.9, 1.8, 2.4, 3.5, 3.9, 4.4, 5.1, 5.6, 6.3), 
size=c(1.4, 2.6, 1.0, 3.7, 5.5, 3.2, 3.0, 4.9, 6.3))

# Display data
moust.data

# plot data
plot(mouse.data$weight, mouse.data$size)

# call Linear Regresion Funtion.
mouse.regression <- lm (size ~ weight, data = mouse.data)
# Summary
summary (mouse.regression)

# draw a regression line
abline (mouse.regression, col="blue")